﻿$(document).ready(function () {
    //Form validation
    $("#rolecreate").validate({
    });
   
    SetPageUrlWithParams('#goback', "/admin/Roles/Index");
});

