﻿$(document).ready(function () {
    AppendQueryStringToLinks();
});