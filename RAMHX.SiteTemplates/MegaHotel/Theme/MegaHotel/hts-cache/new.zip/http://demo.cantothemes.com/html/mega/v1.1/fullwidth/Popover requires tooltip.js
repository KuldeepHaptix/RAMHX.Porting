<!DOCTYPE html>
<html lang="en">

<head>
	
	<!-- Meta -->
	<meta charset="utf-8">
	<title>SeleMak - Responsive WordPress Theme | CantoThemes</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
	
	<!-- Css -->


	<link href="css/template.min.css" rel="stylesheet" media="screen">

	<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">

	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800,300' rel='stylesheet' type='text/css'>
	
	<!--[if lt IE 9]>
		<script type="text/javascript">/*@cc_on'abbr article aside audio canvas details figcaption figure footer header hgroup mark meter nav output progress section summary subline time video'.replace(/\w+/g,function(n){document.createElement(n)})@*/</script>
	<![endif]-->
    
</head>
	
<body>

<!-- Header -->
<header class="switcher-bar clearfix">

	<!-- Logo -->
	<div class="logo textual pull-left">
		<a href="#" title="Switcher" style="font-weight:600;">
			<span style="color:#00adf2;">Canto</span><span style="color:#fff;font-weight:300;">Themes</span>
		</a>
	</div>

	<!-- Product Switcher -->
	<div class="product-switcher pull-left">
		<a href="#" title="Select a Product">
			SeleMak <span class="badge">WP</span>
		</a>
	</div>

	<!-- Bar Remove Button -->
	<div class="remove-btn header-btn pull-right">
		<a href="http://selemak.cantothemes.com/" title="Close this bar" class="icon-remove"></a>
	</div>

	<!-- Purchase Button -->
	<div class="purchase-btn header-btn pull-right">
		<a href="http://themeforest.net/item/selemak-responsive-wordpress-theme/6533968?ref=CantoThemes" title="Purchase" class=""><i class="icon-shopping-cart"></i> Purchase</a>
	</div>

	<!-- Mobile Button -->
	<div class="mobile-btn header-btn pull-right hidden-xs">
		<a href="#" title="Smartphone View" class="icon-mobile-phone"></a>
	</div>

	<!-- Tablet Button -->
	<div class="tablet-btn header-btn pull-right hidden-xs">
		<a href="#" title="Tablet View" class="icon-tablet"></a>
	</div>

	<!-- Desktop Button -->
	<div class="desktop-btn header-btn pull-right hidden-xs">
		<a href="#" title="Desktop View" class="icon-desktop"></a>
	</div>

</header>

<!-- Products List -->
<section class="switcher-body">

	<a href="#" title="Prev" class="icon-chevron-left products-prev"></a>

	<div class="products-wrapper">
		<div class="products-list clearfix">
			<a class="product pull-left" href="http://demo.cantothemes.com/?item=selemakwp" title="SeleMak - Responsive WordPress Theme""><img src="http://3.s3.envato.com/files/77471885/selemak-wp-570.jpg" alt="SeleMak" width="236" height="120"><span class="title">SeleMak</span><span class="badge">WP</span></a><a class="product pull-left" href="http://demo.cantothemes.com/?item=selemakhtml" title="SeleMak - Responsive HTML5 Template""><img src="http://2.s3.envato.com/files/70958707/570.jpg" alt="SeleMak" width="236" height="120"><span class="title">SeleMak</span><span class="badge">HTML</span></a><a class="product pull-left" href="http://demo.cantothemes.com/?item=robizhtml" title="ROBIZ - Responsive Site Template""><img src="http://0.s3.envato.com/files/63626268/590.png" alt="ROBIZ" width="236" height="120"><span class="title">ROBIZ</span><span class="badge">HTML</span></a>		</div>
	</div>

	<a href="#" title="Next" class="icon-chevron-right products-next"></a>

</section>


<!-- Product iframe -->
<iframe class="product-iframe" src="http://selemak.cantothemes.com/" frameborder="0" border="0"></iframe>

<!-- Preloader -->
<div class="preloader"></div>
<div class="preloading-icon"><i class="icon-refresh icon-spin"></i></div>

<!-- Javascript -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>



<script src="js/application.min.js"></script>


	
</body>

</html>
